﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Repository
{
    public class Repository
    {
        private int id;
        private Dictionary<int, Person> data;

        public Repository()
        {
            this.id = 0;
            this.data = new Dictionary<int, Person>();
        }

        public int Count
        {
            get { return this.data.Count; }
        }

        public void Add(Person person)
        {
            data.Add(id++, person);
        }

        public Person Get(int id)
        {
            return data[id];
        }

        public bool Update(int id, Person newPerson)
        {
            if (!data.ContainsKey(id))
            {
                return false;
            }

            data[id] = newPerson;

            return true;
        }

        public bool Delete(int id)
        {
            if (!data.ContainsKey(id))
            {
                return false;
            }

            data.Remove(id);

            return true;
        }
    }
}
