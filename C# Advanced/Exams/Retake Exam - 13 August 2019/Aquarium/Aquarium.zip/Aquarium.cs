﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquariumAdventure
{
    public class Aquarium
    {
        private List<Fish> fishInPool;

        public Aquarium(string name, int capacity, int size)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.Size = size;
            this.fishInPool = new List<Fish>();
        }

        public string Name { get; }

        public int Capacity { get; }

        public int Size { get; }

        public void Add(Fish fish)
        {
            if(!this.fishInPool.Any(f => f.Name == fish.Name) && this.fishInPool.Count < this.Capacity)
            {
                this.fishInPool.Add(fish);
            }
        }

        public bool Remove(string name)
        {
            if (this.fishInPool.Any(f => f.Name == name))
            {
                return this.fishInPool
                    .Remove(this.fishInPool
                    .Where(f => f.Name == name)
                    .FirstOrDefault());
            }

            return false;
        }

        public Fish FindFish(string name)
        {
            if (this.fishInPool.Any(f => f.Name == name))
            {
                return this.fishInPool
                    .Where(f => f.Name == name)
                    .FirstOrDefault();
            }

            return null;
        }

        public string Report()
        {
            StringBuilder report = new StringBuilder();

            report.AppendLine("Aquarium Info:");
            report.AppendLine($"Aquarium: {this.Name} ^ Size: {this.Size}");

            foreach (var fish in this.fishInPool)
            {
                report.AppendLine(fish.ToString());
            }

            return report.ToString().TrimEnd();
        }
    }
}
