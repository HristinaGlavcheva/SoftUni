﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquariumAdventure
{
    public class Aquarium
    {
        private Dictionary<string, Fish> fishInPool;

        public Aquarium(string name, int capacity, int size)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.Size = size;
            this.fishInPool = new Dictionary<string, Fish>();
        }

        public string Name { get; }

        public int Capacity { get; }

        public int Size { get; }

        public void Add(Fish fish)
        {
            if(!this.fishInPool.ContainsKey(fish.Name) && this.fishInPool.Count < this.Capacity)
            {
                this.fishInPool.Add(fish.Name, fish);
            }
        }

        public bool Remove(string name)
        {
            if (this.fishInPool.ContainsKey(name))
            {
                this.fishInPool.Remove(name);
                return true;
            }

            return false;
        }

        public Fish FindFish(string name)
        {
            if (this.fishInPool.ContainsKey(name))
            {
                foreach (var (fishName, fish) in fishInPool)
                {
                    if(fishName == name)
                    {
                        return fish;
                    }
                }
            }

            return null;
        }

        public string Report()
        {
            StringBuilder report = new StringBuilder();

            report.AppendLine("Aquarium Info:");
            report.AppendLine($"Aquarium: {this.Name} ^ Size: {this.Size}");

            foreach (var (poolName, fish) in fishInPool)
            {
                report.AppendLine(fish.ToString());
            }

            return report.ToString().TrimEnd();
        }
    }
}
