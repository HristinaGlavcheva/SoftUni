﻿using System.Collections.Generic;
using System.Linq;

namespace BoxOfT
{
    public class Box<T>
    {
        private int count;
        private List<T> data;

        public Box()
        {
            this.data = new List<T>();
        }

        public int Count
        {
            get { return this.data.Count; }
        }

        public void Add(T element)
        {
            this.data.Add(element);
        }

        public T Remove()
        {
            T removed = this.data.Last();

            this.data.RemoveAt(this.data.Count - 1);

            return removed;
        }
    }
}
