﻿using System;

namespace CustomDoublyLinkedList
{
    public class DoublyLinkedList
    {
        private ListNode head;
        private ListNode tail;

        public int this[int index]
        {
            get
            {
                int[] arr = this.ToArray();

                if(index < 0 || index >= arr.Length)
                {
                    throw new ArgumentException("Index outside of the bounds of the list.", nameof(index));
                }

                return arr[index];
            }
        }

        public int Count { get; private set; }

        public void AddFirst(int element)
        {
            if(this.Count == 0)
            {
                this.head = this.tail = new ListNode(element);
            }
            else
            {
                ListNode newHead = new ListNode(element);
                ListNode oldHead = this.head;

                this.head = newHead;
                newHead.NextNode = oldHead;
                oldHead.PreviousNode = newHead;
            }

            this.Count++;
        }

        public void AddLast(int element)
        {
            if(this.Count == 0)
            {
                this.head = this.tail = new ListNode(element);
            }
            else
            {
                ListNode newTail = new ListNode(element);
                ListNode oldTail = this.tail;

                this.tail = newTail;
                newTail.PreviousNode = oldTail;
                oldTail.NextNode = newTail;
            }

            this.Count++;
        }

        public int RemoveFirst()
        {
            int? removedEl = this.head?.Value;
            
            if (this.Count == 0 || !removedEl.HasValue)
            {
                throw new InvalidOperationException("List is empty.");
            }
            else if (this.Count == 1)
            {
                this.head = null;
                this.tail = null;
            }
            else
            {
                ListNode newHead = this.head.NextNode;
                newHead.PreviousNode = null;
                this.head = newHead;
            }

            this.Count--;

            return removedEl.Value;
        }

        public int RemoveLast()
        {
            if(this.Count == 0)
            {
                throw new InvalidOperationException("List is empty.");
            }

            int removedElement = this.tail.Value;

            if(this.Count == 1)
            {
                this.head = null;
                this.tail = null;
            }
            else
            {
                ListNode newTail = this.tail.PreviousNode;
                newTail.NextNode = null;
                this.tail = newTail;
            }

            this.Count--;

            return removedElement;
        }

        public void ForEach(Action<int> action)
        {
            ListNode currentEl = this.head;

            while (currentEl != null)
            {
                action(currentEl.Value);
                currentEl = currentEl.NextNode;
            }
        }

        public int[] ToArray()
        {
            int[] arr = new int[this.Count];
            
            int counter = 0;

            ListNode currentEl = this.head;

            while(currentEl != null)
            {
                arr[counter] = currentEl.Value;
                counter++;
                currentEl = currentEl.NextNode;
            }

            return arr;
        }


    }
}
