﻿using System;

namespace P06_Sneaking
{
    class Sneaking
    {
        static char[][] room;
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            InitializeRoom(n);

            char[] moves = Console.ReadLine().ToCharArray();

            int[] playerPosition = new int[2];

            FindInitialPlayerPosition(playerPosition);

            int playerRow = playerPosition[0];
            int playerCol = playerPosition[1];

            for (int i = 0; i < moves.Length; i++)
            {
                MoveEnemy();

                int[] getEnemy = new int[2];
                for (int j = 0; j < room[playerPosition[0]].Length; j++)
                {
                    if (room[playerPosition[0]][j] != '.' && room[playerPosition[0]][j] != 'S')
                    {
                        getEnemy[0] = playerPosition[0];
                        getEnemy[1] = j;
                    }
                }
                if (playerPosition[1] < getEnemy[1] && room[getEnemy[0]][getEnemy[1]] == 'd' && getEnemy[0] == playerPosition[0])
                {
                    room[playerPosition[0]][playerPosition[1]] = 'X';
                    Console.WriteLine($"Sam died at {playerPosition[0]}, {playerPosition[1]}");
                    for (int row = 0; row < room.Length; row++)
                    {
                        for (int col = 0; col < room[row].Length; col++)
                        {
                            Console.Write(room[row][col]);
                        }
                        Console.WriteLine();
                    }
                    Environment.Exit(0);
                }
                else if (getEnemy[1] < playerPosition[1] && room[getEnemy[0]][getEnemy[1]] == 'b' && getEnemy[0] == playerPosition[0])
                {
                    room[playerPosition[0]][playerPosition[1]] = 'X';
                    Console.WriteLine($"Sam died at {playerPosition[0]}, {playerPosition[1]}");
                    for (int row = 0; row < room.Length; row++)
                    {
                        for (int col = 0; col < room[row].Length; col++)
                        {
                            Console.Write(room[row][col]);
                        }
                        Console.WriteLine();
                    }
                    Environment.Exit(0);
                }


                room[playerPosition[0]][playerPosition[1]] = '.';
                switch (moves[i])
                {
                    case 'U':
                        playerPosition[0]--;
                        break;
                    case 'D':
                        playerPosition[0]++;
                        break;
                    case 'L':
                        playerPosition[1]--;
                        break;
                    case 'R':
                        playerPosition[1]++;
                        break;
                    default:
                        break;
                }
                room[playerPosition[0]][playerPosition[1]] = 'S';

                for (int j = 0; j < room[playerPosition[0]].Length; j++)
                {
                    if (room[playerPosition[0]][j] != '.' && room[playerPosition[0]][j] != 'S')
                    {
                        getEnemy[0] = playerPosition[0];
                        getEnemy[1] = j;
                    }
                }
                if (room[getEnemy[0]][getEnemy[1]] == 'N' && playerPosition[0] == getEnemy[0])
                {
                    room[getEnemy[0]][getEnemy[1]] = 'X';
                    Console.WriteLine("Nikoladze killed!");
                    for (int row = 0; row < room.Length; row++)
                    {
                        for (int col = 0; col < room[row].Length; col++)
                        {
                            Console.Write(room[row][col]);
                        }
                        Console.WriteLine();
                    }
                    Environment.Exit(0);
                }
            }
        }

        private static bool IsInsideRoom(int targetRow, int targetCol)
        {
            return targetRow >= 0 && targetRow < room.Length && targetCol >= 0 && targetCol < room[targetRow].Length;
        }

        private static void MoveEnemy()
        {
            for (int row = 0; row < room.Length; row++)
            {
                for (int col = 0; col < room[row].Length; col++)
                {
                    if (room[row][col] == 'b')
                    {
                        if (IsInsideRoom(row, col + 1))
                        {
                            room[row][col] = '.';
                            room[row][col + 1] = 'b';
                            col++;
                        }
                        else
                        {
                            room[row][col] = 'd';
                        }
                    }
                    else if (room[row][col] == 'd')
                    {
                        if (IsInsideRoom(row, col - 1))
                        {
                            room[row][col] = '.';
                            room[row][col - 1] = 'd';
                        }
                        else
                        {
                            room[row][col] = 'b';
                        }
                    }
                }
            }
        }

        private static void FindInitialPlayerPosition(int[] playerPosition)
        {
            for (int row = 0; row < room.Length; row++)
            {
                for (int col = 0; col < room[row].Length; col++)
                {
                    if (room[row][col] == 'S')
                    {
                        playerPosition[0] = row;
                        playerPosition[1] = col;
                    }
                }
            }
        }

        private static void InitializeRoom(int n)
        {
            room = new char[n][];

            for (int row = 0; row < n; row++)
            {
                char[] currentRow = Console.ReadLine().ToCharArray();

                room[row] = new char[currentRow.Length];

                for (int col = 0; col < currentRow.Length; col++)
                {
                    room[row][col] = currentRow[col];
                }
            }
        }
    }
}
