﻿namespace Telephony.Contracts
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}
