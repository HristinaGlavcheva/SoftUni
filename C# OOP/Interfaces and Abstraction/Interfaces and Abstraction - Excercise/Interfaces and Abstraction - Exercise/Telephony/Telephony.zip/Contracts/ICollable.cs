﻿namespace Telephony.Contracts
{
    public interface ICollable
    {
        string Call(string number);
    }
}
