﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Common
{
    public static class GlobalConstants
    {
        public static string InvalidNumberMessage = "Invalid number!";
        public static string InvalidUrlMessage = "Invalid URL!";
    }
}
