﻿using Git.ViewModels.Commits;

namespace Git.Services
{
    public interface ICommitsService
    {
        void Create(string id)
    }
}
