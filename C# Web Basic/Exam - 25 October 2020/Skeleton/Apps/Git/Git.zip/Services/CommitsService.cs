﻿using Git.Data;
using Git.ViewModels.Commits;
using Git.ViewModels.Repositories;
using System;
using System.Linq;

namespace Git.Services
{
    public class CommitsService : ICommitsService
    {
        private readonly ApplicationDbContext db;

        public CommitsService(ApplicationDbContext db)
        {
            this.db = db;
        }
        
        public void Create(string id)
        {
            var commit = this.db.Commits.Where(x => x.Id == id)
                .Select(x => new Commit
                {
                    Description = x.Description,
                    CreatedOn = x.CreatedOn,
                    CreatorId = x.CreatorId,
                    RepositoryId = x.Repository.Id
                }).FirstOrDefault();

            this.db.Commits.Add(commit);
            this.db.SaveChanges();
        }
    }
}
