﻿using Git.ViewModels.Commits;

namespace Git.Services
{
    public interface ICommitsService
    {
        public CommitViewModel Create(string id);
    }
}
