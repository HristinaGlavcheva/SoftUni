﻿using Git.Data;
using Git.ViewModels.Commits;
using Git.ViewModels.Repositories;
using System;
using System.Linq;

namespace Git.Services
{
    public class CommitsService : ICommitsService
    {
        private readonly ApplicationDbContext db;

        public CommitsService(ApplicationDbContext db)
        {
            this.db = db;
        }
        
        public CommitViewModel Create(string id)
        {
            var viewModel = this.db.Commits.Where(x => x.Id == id)
                .Select(x => new CommitViewModel
                {
                    Description = x.Description,
                    RepositoryName = x.Repository.Name,
                    RepositoryId = x.Repository.Id
                }).FirstOrDefault();

            this.db.Commits.Add(viewModel);
            this.db.SaveChanges();

            return viewModel;
        }
    }
}
