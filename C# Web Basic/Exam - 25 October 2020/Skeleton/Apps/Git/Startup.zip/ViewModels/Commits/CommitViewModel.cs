﻿namespace Git.ViewModels.Commits
{
    public class CommitViewModel
    {
        public string Description { get; set; }

        public string RepositoryName { get; set; }

        public string RepositoryId { get; set; }
    }
}
