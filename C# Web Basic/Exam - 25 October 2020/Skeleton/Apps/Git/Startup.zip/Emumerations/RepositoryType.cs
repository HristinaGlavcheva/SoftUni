﻿namespace Git.Emumerations
{
    public enum RepositoryType
    {
        Public = 1,
        Private = 2,
    }
}
