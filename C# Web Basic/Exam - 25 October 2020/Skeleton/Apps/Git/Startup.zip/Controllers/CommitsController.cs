﻿using Git.Services;
using Git.ViewModels.Commits;
using SUS.HTTP;
using SUS.MvcFramework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Git.Controllers
{
    public class CommitsController : Controller
    {
        private readonly ICommitsService commitsService;

        public CommitsController(ICommitsService commitsService)
        {
            this.commitsService = commitsService;
        }
        
        public HttpResponse All()
        {
            return this.View();
        }

        public HttpResponse Create()
        {
            return this.View();
        }

        [HttpPost]
        public HttpResponse Create(CommitViewModel input, string id)
        {
            if(input.Description.Length < 5)
            {
                return this.Error("Description should be with minimum length of 5 characters.");
            }
            
            this.commitsService.Create(input);

            return this.Redirect("Repositories/All");
        }
    }
}
